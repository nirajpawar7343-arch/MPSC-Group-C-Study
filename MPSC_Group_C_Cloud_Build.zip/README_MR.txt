MPSC Group-C Study Android Project

हा Android Studio साठी source project आहे; compiled APK नाही.

APK तयार करण्यासाठी:
1. Android Studio मध्ये हा folder Open करा.
2. Gradle Sync पूर्ण होऊ द्या.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
4. app/build/outputs/apk/debug/app-debug.apk येथे APK मिळेल.

अॅपमध्ये स्थानिक HTML asset आहे. इंटरनेटशिवाय अभ्यासक्रम/टॉपिक ट्रॅकर उघडतो.
नोंद: हा प्रारंभिक source project आहे. पूर्ण अधिकृत अभ्यासक्रम, अद्ययावत चालू घडामोडी,
विस्तृत नोट्स आणि सर्व प्रश्नसंच यांची स्वतंत्र पडताळणी व भर घालणे आवश्यक आहे.


मोबाईलवर Cloud Build करून APK मिळवण्याची पद्धत:
1. GitHub.com वर मोफत खाते तयार करा/Sign in करा.
2. New repository तयार करा; नाव MPSC-Group-C-Study ठेवा.
3. या ZIP मधील सर्व files/folders repository मध्ये upload करा (ZIP फाइल स्वतः upload करू नका; आधी Extract करावी).
4. Repository मधील Actions tab उघडा.
5. Build MPSC Android APK workflow निवडा आणि Run workflow दाबा.
6. Build यशस्वी झाल्यावर workflow run मधील Artifacts विभागातून MPSC-Group-C-Study-APK डाउनलोड करा.
7. ZIP extract करा. app-debug.apk वर टॅप करून Install करा.
